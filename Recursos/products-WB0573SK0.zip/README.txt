
                        SMARTADMIN GETTING STARTED

---------------------------------------------------------------------------
                                                                          |
  Q: Looking for the unminified sources?                                  |
                                                                          |
  They are found under DEVELOPER/COMMON_ASSETS                            |
                                                                          |
---------------------------------------------------------------------------
                                                                          |
  Q: Where is the landing page sources located?                           |
                                                                          |
  They are found under DEVELOPER\COMMON_ASSETS\GOODIES\smartadmin_landing |
                                                                          |
---------------------------------------------------------------------------
                                                                          |
  Q: Do I get support with this theme?                                    |
                                                                          |
  Absolutely, but our support is limited - to view the requirements       |
  please go to www.smartadminsupport.com                                  |
                                                                          |
---------------------------------------------------------------------------
                                                                          |  
  Q: How do I update/upgrade new releases?                                |
                                                                          |  
  All our updates are free. To be notified of updates you must be either  | 
  registered with www.wrapbootstrap.com or following us on twitter        |
  @bootstraphunt.                                                         |
                                                                          |
  To download the latest update please go to:                             |
  https://wrapbootstrap.com/support/download-resender                     |
                                                                          |
---------------------------------------------------------------------------
                                                                          |
  Q: Where is the full documentation?                                     |
                                                                          |  
  The full documentation can be found under the "Documentation" folder    |
---------------------------------------------------------------------------
                                                                          |
  Q: Where can I find more skins and goodies for SmartAdmin?              |
                                                                          |
  You can go to www.smartadminstore.com to find goodies and addons        |
                                                                          |
---------------------------------------------------------------------------
                                                                          |  
  Q: How can I contribute to SmartAdmin?                                  |
                                                                          |  
  SmartAdmin takes a lot of effort to keep it up to date. We have a       |
  small team of 4 and welcome all contributions to this project. Any      |
  contributions you make will be credited and your name will be among     |
  our accolades.                                                          |
                                                                          |
                                                                          | 
  We also accept donations to keep our team running, you can help by      |
  contributing through paypal to myplaneticket@gmail.com; with enough     |
  donations we can hire additional developers and deliver more            |
  frequent updates.                                                       |
                                                                          |
---------------------------------------------------------------------------