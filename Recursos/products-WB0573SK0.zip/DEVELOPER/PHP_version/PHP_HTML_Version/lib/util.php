<?php

defined("DB_HOST") ? null : define("DB_HOST", "127.0.0.1");
defined("DB_USER") ? null : define("DB_USER", "root");
defined("DB_PASSWORD") ? null : define("DB_PASSWORD", "root_password");
defined("DB_NAME") ? null : define("DB_NAME", "db");

?>