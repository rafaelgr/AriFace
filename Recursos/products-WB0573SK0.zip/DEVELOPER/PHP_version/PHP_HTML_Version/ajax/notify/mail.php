<ul class="notification-body">
	<li>
		<span class="unread">
			<a href="javascript:void(0);" class="msg">
				<img src="img/avatars/4.png" alt="" class="air air-top-left margin-top-5" width="40" height="40" />
				<span class="from">John Doe <i class="icon-paperclip"></i></span>
				<time>2 minutes ago</time>
				<span class="subject">Msed quia non numquam eius modi tempora</span>
				<span class="msg-body">Hello again and thanks for being a part of the newsletter. </span>
			</a>
		</span>
	</li>
	<li>
		<span>
			<a href="javascript:void(0);" class="msg">
				<img src="img/avatars/female.png" alt="" class="air air-top-left margin-top-5" width="40" height="40" />
				<span class="from">Sonya Birthday</span>
				<time>Thursday, September 19th</time>
				<span class="subject">Incidunt ut labor</span>
				<span class="msg-body">sed quia non numquam eius modi tempora incidunt ut labor</span>
			</a>
		</span>
	</li>
	<li>
		<span>
			<a href="javascript:void(0);" class="msg">
				<img src="img/avatars/1.png" alt="" class="air air-top-left margin-top-5" width="40" height="40" />
				<span class="from">Cristina Algera</span>
				<time>Sunday, September 15th</time>
				<span class="subject">Best-Selling Teethers</span>
				<span class="msg-body"> ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur?</span>
			</a>
		</span>
	</li>
	<li>
		<span>
			<a href="javascript:void(0);" class="msg">
				<img src="img/avatars/male.png" alt="" class="air air-top-left margin-top-5" width="40" height="40" />
				<span class="from">Lam Tampora</span>
				<time>Saturday, September 14th</time>
				<span class="subject">Deadline due date</span>
				<span class="msg-body">imus qui blanditiis praesentium voluptatum deleniti atque corrup</span>
			</a>
		</span>
	</li>
	<li>
		<span class="unread">
			<a href="javascript:void(0);" class="msg">
				<img src="img/avatars/sunny.png" alt="" class="air air-top-left margin-top-5" width="40" height="40" />
				<span class="from">Project approved! <i class="icon-paperclip"></i></span>
				<time>September 14th</time>
				<span class="subject">Et harum quidem rerum facilis est et expedita distinctio</span>
				<span class="msg-body">...</span>
			</a>
		</span>
	</li>
	<li>
		<span>
			<a href="javascript:void(0);" class="msg">
				<img src="img/avatars/male.png" alt="" class="air air-top-left margin-top-5" width="40" height="40" />
				<span class="from">JEFF, me</span>
				<time>Friday, September 13th</time>
				<span class="subject">Bugs fixed! </span>
				<span class="msg-body">Nam libero tempore, cum soluta nobis est eligendi optio cumque</span>
			</a>
		</span>
	</li>
</ul>